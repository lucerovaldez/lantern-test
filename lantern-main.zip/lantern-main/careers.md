---
title: 'Careers'
date: 2024-11-22T17:01:34+07:00
layout: default
bodyClass: page-careers
career_title: "Black Lantern Security is a Services Oriented Company"
---

{% include banner.html %}
{% include career.html %}
{% include cta-alt.html %}
